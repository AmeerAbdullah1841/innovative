__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/297e0eae4514d0f0.js",
  "static/chunks/turbopack-4c470860a09f0313.js"
])
