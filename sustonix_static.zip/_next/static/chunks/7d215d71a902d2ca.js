__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/297e0eae4514d0f0.js",
  "static/chunks/turbopack-354014b1a5c39398.js"
])
